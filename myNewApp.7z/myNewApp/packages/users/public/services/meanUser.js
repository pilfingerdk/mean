'use strict';

angular.module('mean.users').factory('MeanUser', [

  function() {
    return {
      name: 'users'
    };
  }
]);
